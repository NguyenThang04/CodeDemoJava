/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoasm;
import java.util.Scanner;
/**
 *
 * @author THANG
 */
public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        MyStudents mystudents = new MyStudents();
        int choice;

        do {
            System.out.println("\nQuản lý sinh viên");
            System.out.println("1. Add Student");
            System.out.println("2. Edit Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Sắp xếp học sinh theo điểm");
            System.out.println("5. Tìm kiếm học sinh theo mã số");
            System.out.println("6. Hiển thị danh sách học sinh");
            System.out.println("0. Exit");
            System.out.print("Lựa chọn của bạn: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // clear buffer

            switch (choice) {
                case 1 -> addStudent(mystudents);
                case 2 -> editStudent(mystudents);
                case 3 -> deleteStudent(mystudents);
                case 4 -> mystudents.sortStudentsByGrade();
                case 5 -> searchStudentById(mystudents);
                case 6 -> mystudents.displayStudents();
                case 0 -> System.out.println("Thoát chương trình.");
                default -> System.out.println("Lựa chọn không hợp lệ. Vui lòng thử lại.");
            }
        } while (choice != 0);
    }

    private static void addStudent(MyStudents studentList) {
        System.out.print("Nhập mã số học sinh: ");
        String id = scanner.nextLine();
        System.out.print("Nhập họ và tên học sinh: ");
        String fullName = scanner.nextLine();
        System.out.print("Nhập điểm học sinh: ");
        double grade = scanner.nextDouble();
        scanner.nextLine(); // clear buffer
        studentList.addStudent(new DemoAsm(id, fullName, grade));
    }

    private static void editStudent(MyStudents studentList) {
        System.out.print("Nhập mã số học sinh cần sửa: ");
        String id = scanner.nextLine();
        System.out.print("Nhập họ và tên mới: ");
        String fullName = scanner.nextLine();
        System.out.print("Nhập điểm mới: ");
        double grade = scanner.nextDouble();
        scanner.nextLine(); // clear buffer
        studentList.editStudent(id, fullName, grade);
    }

    private static void deleteStudent(MyStudents studentList) {
        System.out.print("Nhập mã số học sinh cần xóa: ");
        String id = scanner.nextLine();
        studentList.deleteStudent(id);
    }

    private static void searchStudentById(MyStudents studentList) {
        System.out.print("Nhập mã số học sinh cần tìm: ");
        String id = scanner.nextLine();
        studentList.searchStudentById(id);
    }
}

