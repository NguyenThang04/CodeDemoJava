/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoasm;

/**
 *
 * @author THANG
 */
class Node {
    DemoAsm data;   
    Node next;      

    public Node(DemoAsm data) {
        this.data = data;
        this.next = null;
    }
}
