/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoasm;
/**
 *
 * @author THANG
 */
class MyStudents {
    private Node head;

    public void addStudent(DemoAsm demoasm) {
        Node newNode = new Node(demoasm);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        System.out.println("Thêm học sinh thành công!");
    }

    public void editStudent(String id, String fullName, double grade) {
        Node current = head;
        while (current != null) {
            if (current.data.getId().equals(id)) {
                current.data.setFullName(fullName);
                current.data.setGrade(grade);
                System.out.println("Sửa thông tin học sinh thành công!");
                return;
            }
            current = current.next;
        }
        System.out.println("Không tìm thấy học sinh với mã số: " + id);
    }

    public void deleteStudent(String id) {
        if (head == null) return;

        if (head.data.getId().equals(id)) {
            head = head.next;
            System.out.println("Xóa học sinh thành công!");
            return;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.data.getId().equals(id)) {
                current.next = current.next.next;
                System.out.println("Xóa học sinh thành công!");
                return;
            }
            current = current.next;
        }
        System.out.println("Không tìm thấy học sinh với mã số: " + id);
    }

    public void sortStudentsByGrade() {
        if (head == null || head.next == null) return;

        for (Node i = head; i.next != null; i = i.next) {
            for (Node j = i.next; j != null; j = j.next) {
                if (i.data.getGrade() < j.data.getGrade()) {
                    DemoAsm temp = i.data;
                    i.data = j.data;
                    j.data = temp;
                }
            }
        }
        System.out.println("Danh sách học sinh sau khi sắp xếp theo điểm:");
        displayStudents();
    }

    public void searchStudentById(String id) {
        Node current = head;
        while (current != null) {
            if (current.data.getId().equals(id)) {
                System.out.println("Thông tin học sinh tìm thấy:");
                System.out.println(current.data);
                return;
            }
            current = current.next;
        }
        System.out.println("Không tìm thấy học sinh với mã số: " + id);
    }

    public void displayStudents() {
        if (head == null) {
            System.out.println("Danh sách học sinh trống.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }
}

