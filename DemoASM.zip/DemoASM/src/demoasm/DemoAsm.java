/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoasm;

/**
 *
 * @author THANG
 */
class DemoAsm {
    private String id;
    private String fullName;
    private double grade;
    private String rank;

    public DemoAsm(String id, String fullName, double grade) {
        this.id = id;
        this.fullName = fullName;
        this.grade = grade;
        this.rank = calculateRank(grade);
    }

    private String calculateRank(double grade) {
        if (grade >= 8.5) return "Giỏi";
        else if (grade >= 7.0) return "Khá";
        else if (grade >= 5.0) return "Trung Bình";
        else return "Yếu";
    }

    public String getId() { return id; }
    public String getFullName() { return fullName; }
    public double getGrade() { return grade; }
    public String getRank() { return rank; }

    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setGrade(double grade) {
        this.grade = grade;
        this.rank = calculateRank(grade);
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Tên: " + fullName + ", Điểm: " + grade + ", Xếp hạng: " + rank;
    }
}