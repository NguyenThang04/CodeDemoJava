/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sinhviensortbubble;
import java.util.LinkedList;
import java.util.Scanner;


/**
 *
 * @author THANG
 */

public class MyStudent {
    private LinkedList<Student> students = new LinkedList<>();
    private Scanner scanner = new Scanner(System.in);

    public void addStudent() {
        try {
            String id = inputStudentId();
            String fullName = inputStudentName();
            double marks = inputStudentMarks();

            students.add(new Student(id, fullName, marks));
            System.out.println("Student added successfully.");
        } catch (Exception e) {
            System.out.println("An error occurred while adding the student. Please try again.");
        }
    }

    public void editStudent() {
        try {
            System.out.print("Enter Student ID to edit: ");
            String id = scanner.nextLine();
            Student student = findStudentById(id);

            if (student == null) {
                System.out.println("Student not found.");
                return;
            }

            System.out.println("Editing student: " + student);
            String fullName = inputStudentName();
            double marks = inputStudentMarks();

            student.setFullName(fullName);
            student.setMarks(marks);
            System.out.println("Student updated successfully.");
        } catch (Exception e) {
            System.out.println("An error occurred while editing the student. Please try again.");
        }
    }

    public void deleteStudent() {
        try {
            System.out.print("Enter Student ID to delete: ");
            String id = scanner.nextLine();
            Student student = findStudentById(id);

            if (student == null) {
                System.out.println("Student not found.");
                return;
            }

            students.remove(student);
            System.out.println("Student deleted successfully.");
        } catch (Exception e) {
            System.out.println("An error occurred while deleting the student. Please try again.");
        }
    }

    public void searchStudent() {
        try {
            System.out.print("Enter Student ID to search: ");
            String id = scanner.nextLine();
            Student student = findStudentById(id);
            if (student == null) {
                System.out.println("Student not found.");
            } else {
                System.out.println("Student found: " + student);
            }
        } catch (Exception e) {
            System.out.println("An error occurred while searching for the student. Please try again.");
        }
    }

    void bubbleSort() {
        int n = students.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (students.get(j).getMarks() > students.get(j + 1).getMarks()) {
                    Student temp = students.get(j);
                    students.set(j, students.get(j + 1));
                    students.set(j + 1, temp);
                }
            }
        }
    }

    public void displayStudents() {
        try {
            for (Student student : students) {
                System.out.println(student);
            }
        } catch (Exception e) {
            System.out.println("An error occurred while displaying the students. Please try again.");
        }
    }

    private String inputStudentId() {
        String id;
        while (true) {
            System.out.print("Enter Student ID: ");
            id = scanner.nextLine();
            if (id.matches("\\d+")) {
                break;
            } else {
                System.out.println("Invalid ID. ID should contain digits only.");
            }
        }
        return id;
    }

    private String inputStudentName() {
        String name;
        while (true) {
            System.out.print("Enter Student's full name: ");
            name = scanner.nextLine();
            if (name.matches("[a-zA-Z ]+")) {
                break;
            } else {
                System.out.println("Invalid name. Name should contain letters only.");
            }
        }
        return name;
    }

    private double inputStudentMarks() {
        double marks;
        while (true) {
            System.out.print("Enter Student Marks: ");
            try {
                marks = Double.parseDouble(scanner.nextLine());
                if (marks >= 0 && marks <= 10) {
                    break;
                } else {
                    System.out.println("Invalid marks. Marks should be between 0 and 10.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
        return marks;
    }

    private Student findStudentById(String id) {
        try {
            for (Student student : students) {
                if (student.getId().equals(id)) {
                    return student;
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred while finding the student. Please try again.");
        }
        return null;
    }

    void sortStudents() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


