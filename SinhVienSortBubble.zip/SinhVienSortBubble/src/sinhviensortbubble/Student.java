/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sinhviensortbubble;

/**
 *
 * @author THANG
 */
public class Student {
    private String id;
    private String fullName;
    private double marks;
    private String ranking;

    public Student(String id, String fullName, double marks) {
        this.id = id;
        this.fullName = fullName;
        this.marks = marks;
        this.ranking = calculateRanking(marks);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public double getMarks() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks = marks;
        this.ranking = calculateRanking(marks);
    }

    public String getRanking() {
        return ranking;
    }

    private String calculateRanking(double marks) {
        if (marks < 5.0) return "Fail";
        else if (marks < 6.5) return "Medium";
        else if (marks < 7.5) return "Good";
        else if (marks < 9.0) return "Very Good";
        else return "Excellent";
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + fullName + ", Marks: " + marks + ", Ranking: " + ranking;
    }
}