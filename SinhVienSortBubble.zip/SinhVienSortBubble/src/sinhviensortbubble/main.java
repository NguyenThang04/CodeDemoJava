/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sinhviensortbubble;

import java.util.Scanner;

/**
 *
 * @author THANG
 */
public class main {
    public static void main(String[] args) {
        MyStudent mystudent = new MyStudent();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Edit Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Search Student");
            System.out.println("5. Sort Students by Marks");
            System.out.println("6. Display All Students");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    mystudent.addStudent();
                    break;
                case "2":
                    mystudent.editStudent();
                    break;
                case "3":
                    mystudent.deleteStudent();
                    break;
                case "4":
                    mystudent.searchStudent();
                    break;
                case "5":
                    mystudent.sortStudents();
                    break;
                case "6":
                    mystudent.displayStudents();
                    break;
                case "0":
                    System.out.println("Exiting program...");
                    return;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}


